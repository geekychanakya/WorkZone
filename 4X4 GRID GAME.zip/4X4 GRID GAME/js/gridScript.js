$(document).ready(function(){
        get_cards();
    });
    
    var cards_array = ['#FFFF00','#FFFF00','#F4511E','#F4511E','#1A237E','#1A237E','#9C27B0','#9C27B0','#00E676','#00E676','#00BCD4','#00BCD4','#E91E63','#E91E63','#b71c1c','#b71c1c'];
    var cards_to_compare = [];
    var card_class_Key = [];
    var match_count = 0, score = 0, steps = 0;  
    var theOnclickItem = '';

    //------------- to get the cards --------------------------------------------------------------------------------------
    function get_cards(){
        var data = '';
        var temp = 0;
        var randomPos = 0;
        //--------------- shuffle the position of the cards ---------------------------------------------------------------
        for(var i=0; i< cards_array.length; i++){
            randomPos = Math.round(Math.random() * i);
            temp = cards_array[i];
            cards_array[i] = cards_array[randomPos];
            cards_array[randomPos] = temp;
        }
        
        //--------------- create the section for cards --------------------------------------------------------------------
        for(var j=0; j< cards_array.length; j++){
            data += '<div class="card-'+ j + '" onclick="matchCards(this, \''+ cards_array[j] +'\')"></div>';
        }
        $('.gridContainer').append(data);
    }
    
    //------------- to clear the score and steps --------------------------------------------------------------------------
    function clearCounters(){
        score = 0; steps = 0;
        $('.theSteps')[0].innerHTML = 0;
        $('.theScore')[0].innerHTML = 0;
        $('.successMsg')[0].innerHTML = "";
    }

    //------------- function to calculate combination of flipping the cards -----------------------------------------------
    function matchCards(card, value){
        
        if(card.innerHTML == "" && cards_to_compare.length < 2){
            steps += 1;
            $('.theSteps')[0].innerHTML = steps;
            //$(card).css({"background":value, "transition":"background 1.5s linear 0s"});
            $(card).css({"background":value, "-webkit-transform":"rotate(360deg)", "transform":"rotate(360deg)"});
            var theKey = $(card).attr('class');
            //------------------ When one card is clicked ------------------------------------------------------------------
            if(cards_to_compare.length == 0){
                cards_to_compare.push(value);
                card_class_Key.push(theKey);
                theOnclickItem = $("."+card_class_Key[0]).attr('onclick');
                $("."+card_class_Key[0]).attr('onclick', '');
            }
            //------------------ When two cards are clicked and the first one is comapred with the second one --------------
            else if(cards_to_compare.length == 1){
                cards_to_compare.push(value);
                card_class_Key.push(theKey);
                
                //-------------- Compare the clicked cards -----------------------------------------------------------------
                if(cards_to_compare[0] == cards_to_compare[1]){
                    match_count += 2;
                    score += 20;
                    $("."+card_class_Key[0]).attr('onclick', '');
                    $("."+card_class_Key[1]).attr('onclick', '');
                    $('.theScore')[0].innerHTML = score;
                    cards_to_compare = [];
                    card_class_Key = [];
                    
                    //---------- the first card is equal to the second card -----------------------------------------------
                    if(match_count == cards_array.length){
                        setTimeout(function(){
                            alert('Cards Matched..!!!');
                        },500);
                        $('.successMsg').append("Cards Matched..");
                        $('.gridContainer')[0].innerHTML = "";
                        get_cards();
                        setTimeout(clearCounters, 1000);
                    }
                }
                
                else{
                    //---------- the first card is not equal to the second card -------------------------------------------
                    function flip_card_pos(){
                        var card1 = $('.'+card_class_Key[0]);
                        var card2 = $('.'+card_class_Key[1]);
                        $(card1).attr('onclick', theOnclickItem);
                        $(card1).css({"background":"url(images/tony.jpg)","background-size": "100% 100%","background-repeat":"no-repeat","-webkit-transform":"rotate(0deg)", "transform":"rotate(0deg)"});
                        $(card1)[0].innerHTML = "";
                        $(card2).css({"background":"url(images/tony.jpg)","background-size": "100% 100%","background-repeat":"no-repeat","-webkit-transform":"rotate(0deg)", "transform":"rotate(0deg)"});
                        $(card2)[0].innerHTML = "";
                        cards_to_compare = [];
                        card_class_Key = [];
                        score -= 5;
                        $('.theScore')[0].innerHTML = score;
                    }
                    setTimeout(flip_card_pos, 1400);
                }
                
            }
        }
    }