//using ---- https://github.com/jascination/Angular-JSON-Google-Map/blob/master/README.md

//Initializing the application
var module = angular.module("locateInGoogleMaps", ["google-maps"]).
             config(['$httpProvider', function ($httpProvider) {
                 delete $httpProvider.defaults.headers.common['X-Requested-With']; //Fixes cross domain requests
             }]);

module.controller('locationTrackerCtrl', ['$scope', '$http', '$filter', function ($scope, $http, $filter) {
    //Start Data Fetch
    $scope.callMyApi = function (){
    $http({
            url: "http://43.252.91.54:6015/iview",
            dataType: "json",
            method: "POST",
            data: $.param({apiKey:"ikJRNTGwxVrFCql4WJ"}),
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            }
        }).success(function(data){
            //console.log(data);
            $scope.places = data;
            $scope.markersProperty = data;
            $scope.filteredMarkersProperty = $scope.markersProperty;
        
        }).error(function(error){
            $scope.error = error;
        });
    };
    
    $scope.callMyApi();
    setInterval(function(){
        $scope.callMyApi();
    }, 10000)
    
 //End Data Fetch
    
 //Start Functions for Controller 
    $scope.showAll = function($event){
        $scope.orderProp ="0";
        $scope.filteredMarkersProperty = $scope.places;
        $scope.zoomProperty = 5;
        calcFocus();
    }

     $scope.select = function($event){
        var theName = $event.name;
        var lat = $event.latitude;
        var lng = $event.longitude;
        $scope.filteredMarkersProperty = [$event];
        $scope.centerProperty.lat = lat;
        $scope.centerProperty.lng = lng;
        $scope.zoomProperty = 15;
        calcFocus();
     }
     
    function calcFocus(){
        var lats = [], longs = [], counter = [];
        for(i=0; i<$scope.filteredMarkersProperty.length; i++)
        {
            lats[i] = $scope.filteredMarkersProperty[i].latitude;
            longs[i] = $scope.filteredMarkersProperty[i].longitude;
        }
        var latCount = 0;
        var longCount = 0;

        for (i=0; i<lats.length; i++){
            latCount += lats[i];
            longCount += longs[i];
        }

        latCount = latCount / lats.length;
        longCount = longCount / longs.length;
        $scope.centerProperty.lat = latCount;
        $scope.centerProperty.lng = longCount;
    };


    angular.extend($scope, {
        /** the initial center of the map */
        centerProperty: {
            lat:19.2403,
            lng:73.1305
        },

        /** the initial zoom level of the map */
        zoomProperty: 10,

        /** list of markers to put in the map */
        markersProperty : [],

        // These 2 properties will be set when clicking on the map - click event
        clickedLatitudeProperty: null,  
        clickedLongitudeProperty: null
    });    

 }]);


