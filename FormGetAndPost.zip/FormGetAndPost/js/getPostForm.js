//Initializing the application
var app = angular.module("workingApp", []);

app.factory("PostMyFactoryData", [ '$http', function($http){
    var theData = {};
    
    theData.SendDataToURL = function(rawData){
        $http.post("https://randomform.herokuapp.com/submit",rawData).success(function(response){
            console.log(response.status);      
        });
    };
    
    return theData;
}]);

app.controller('getPostFormCtrl', ['$scope', '$http', 'PostMyFactoryData', function ($scope, $http, PostMyFactoryData) {
    $scope.hasData = false;
    
    //Start Data Fetch
    $scope.callMyApi = function (){
    $http({
            url: "https://randomform.herokuapp.com/",
            dataType: "json",
            method: "GET",
            data: {}
        }).success(function(data){
            console.log(data);
            $scope.formLayouts = data.data;
            $scope.hasData = true;
        
        }).error(function(error){
            $scope.error = error;
        });
    };
    
    //End Data Fetch
    
    $scope.addNewData = function (){ 
        PostMyFactoryData.SendDataToURL($scope.frm);
    }

 }]);