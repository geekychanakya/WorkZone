/*------------------------------/
/   Author : Arnab Saha         /
/   Created On: 12.05.2017      /
/------------------------------*/

var app = angular.module('workingApp', []);

    app.controller('appController', ['$rootScope','$scope', '$http', function ($rootScope, $scope, $http) {
        $rootScope.content = {};
        
        //----- Get Data from JSON
        $http.get('resources/DataTest.json').
            success(function (data) {
                $rootScope.content = data;
                //console.log(data);
            });  
        
        $scope.sectionData = true;
        $scope.theWord = '';
        var count = -1;
        $scope.indx = 0;
        
        //----- Get a new puzzle screen
        $scope.getMySet = function(){
            $scope.indx++;
            $scope.sectionData = true;
            $scope.theWord = '';
            count = -1;
            for(var i = 0; i<$rootScope.content[$scope.indx].word.length; i++){
                $('.box:eq('+i+')')[0].innerHTML = '';
            }
        }
        
        //----- Reset the typed words
        $scope.resetWord = function(){
            $scope.theWord = '';
            count = -1;
            for(var i = 0; i<$rootScope.content[$scope.indx].word.length; i++){
                $('.box:eq('+i+')')[0].innerHTML = '';
            }            
        }
        
        $scope.getNumber = function(num) {
            return new Array(num);   
        }
             
        //----- Get the Selected Character
        $scope.selectedChar = function(ui){
            count++;
            if(count < $rootScope.content[$scope.indx].word.length){
                $('.box:eq('+count+')')[0].innerHTML = ui.value;
            }
            else{
                $('#removeData').removeClass('btnRemove');
                setInterval(function() {                    
                    $('#removeData').addClass('btnRemove');
                }, 300);
            }
            var result = $(".wordContent")[0].innerHTML;
            var res = result.toUpperCase();
            
            $scope.theWord += ui.value;
            
            if($scope.theWord == res){
                $scope.sectionData = false;
            }
        }
        
    }]);

//----- Filter
app.filter("commaBreak",function () {
        return function ( value ) {
            if( !value.length ) 
                return;
            else
            return value.split(',');
        }
});

